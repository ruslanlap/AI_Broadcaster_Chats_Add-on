        // Визначаємо селектори для різних AI-чатів
        const CHAT_SELECTORS = {
          'chat.openai.com': {
            inputField: '#prompt-textarea',
            submitButton: '#prompt-textarea + button',
            alternativeSubmitButton: 'button[data-testid="send-button"]',
            altInputField: 'div[role="textbox"]'
          },
          'chatgpt.com': {
            inputField: '#prompt-textarea',
            submitButton: '#prompt-textarea + button',
            alternativeSubmitButton: 'button[data-testid="send-button"]',
            altInputField: 'div[role="textbox"]'
          },
          'claude.ai': {
            inputField: '.ProseMirror',
            submitButton: 'button[aria-label="Send message"]',
            alternativeInputField: '[contenteditable="true"]'
          },
          'gemini.google.com': {
            // Оновлені селектори для Gemini
            inputField: 'textarea[aria-label="Ask Gemini"], textarea[aria-label="Запитайте Gemini"], textarea',
            submitButton: 'button[aria-label="Send message"], button[aria-label="Надіслати повідомлення"]',
            alternativeSubmitButton: 'button[type="submit"]',
            altInputField: 'div[contenteditable="true"]'
          },
          'grok.com': {
            // Оновлені селектори для Grok
            inputField: 'textarea.resize-none, textarea[placeholder], textarea',
            submitButton: 'button[aria-label="Send message"], button[aria-label="Send"]',
            alternativeSubmitButton: 'button[type="submit"], button:has(svg[viewBox])',
            altInputField: 'div[role="textbox"], div[contenteditable="true"]'
          },
          'chat.deepseek.com': {
            inputField: 'textarea',
            submitButton: 'button[type="submit"]',
            alternativeSubmitButton: 'button[aria-label="Send message"]',
            altInputField: 'div[contenteditable="true"]'
          }
        };

        // Додаємо функцію логування з часовими мітками для легшого налагодження
        function logWithTimestamp(message, data = null) {
          const timestamp = new Date().toISOString().split('T')[1].slice(0, -1);
          if (data) {
            console.log(`[${timestamp}] ${message}`, data);
          } else {
            console.log(`[${timestamp}] ${message}`);
          }
        }

        // Слухаємо повідомлення від popup
        browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
          if (message.action === 'sendMessage') {
            logWithTimestamp('Отримано запит на відправку повідомлення:', message.message.slice(0, 50) + '...');
            try {
              // Додаємо проміс для кращої обробки асинхронності
              injectMessageIntoChat(message.message)
                .then(result => {
                  logWithTimestamp('Результат вставки повідомлення:', result);
                  sendResponse(result);
                })
                .catch(error => {
                  logWithTimestamp('Помилка при вставці повідомлення:', error);
                  sendResponse({ success: false, error: error.message });
                });
            } catch (error) {
              logWithTimestamp('Критична помилка при вставці повідомлення:', error);
              sendResponse({ success: false, error: error.message });
            }
            return true; // Для асинхронної відповіді
          }
        });

        // Функція для визначення, який AI-чат відкритий
        function getCurrentChatType() {
          const url = window.location.href;
          logWithTimestamp('Перевірка поточного URL:', url);

          // Спрощена перевірка для Gemini - використовуємо більш загальний підхід
          if (url.includes('gemini.google.com')) {
            logWithTimestamp('Виявлено Gemini за URL');
            return 'gemini.google.com';
          }

          // Перевіряємо кожен домен підтримуваних чатів
          for (const domain in CHAT_SELECTORS) {
            if (url.includes(domain)) {
              logWithTimestamp(`Виявлено потенційний домен: ${domain}`);

              // Додаткова перевірка для визначення елементів інтерфейсу
              if (hasRequiredElements(domain)) {
                logWithTimestamp(`Підтверджено тип чату: ${domain}`);
                return domain;
              }
            }
          }

          // Додаткова перевірка на основі елементів інтерфейсу
          for (const domain in CHAT_SELECTORS) {
            if (hasRequiredElements(domain)) {
              logWithTimestamp(`Виявлено тип чату за елементами інтерфейсу: ${domain}`);
              return domain;
            }
          }

          logWithTimestamp('Не вдалося визначити тип чату');
          return null;
        }

        // Функція для перевірки наявності необхідних елементів інтерфейсу
        function hasRequiredElements(domain) {
          const selectors = CHAT_SELECTORS[domain];

          // Спочатку перевіряємо всі можливі селектори поля вводу
          const inputSelectors = [
            selectors.inputField, 
            selectors.alternativeInputField,
            selectors.altInputField
          ].filter(Boolean);

          let foundInput = false;

          for (const selector of inputSelectors) {
            const elements = document.querySelectorAll(selector);
            if (elements.length > 0) {
              for (const el of elements) {
                if (isElementVisible(el)) {
                  logWithTimestamp(`Знайдено видиме поле вводу для ${domain}:`, selector);
                  foundInput = true;
                  break;
                }
              }
              if (foundInput) break;
            }
          }

          if (!foundInput) {
            return false;
          }

          // Перевіряємо наявність кнопки відправки, але це не є обов'язковим
          // оскільки ми можемо відправити повідомлення через Enter
          const submitSelectors = [
            selectors.submitButton,
            selectors.alternativeSubmitButton,
            selectors.altSubmitButton
          ].filter(Boolean);

          for (const selector of submitSelectors) {
            const elements = document.querySelectorAll(selector);
            if (elements.length > 0) {
              for (const el of elements) {
                if (isElementVisible(el)) {
                  logWithTimestamp(`Знайдено видиму кнопку відправки для ${domain}:`, selector);
                  return true;
                }
              }
            }
          }

          // Навіть якщо кнопка не знайдена, але є поле вводу, повертаємо true
          logWithTimestamp(`Для ${domain} знайдено поле вводу, але не знайдено кнопку відправки`);
          return foundInput;
        }

        // Функція для вставки повідомлення в чат
        async function injectMessageIntoChat(messageText) {
          const chatType = getCurrentChatType();

          if (!chatType || !CHAT_SELECTORS[chatType]) {
            logWithTimestamp('Невідомий тип чату:', chatType);
            return { success: false, error: 'Невідомий тип чату' };
          }

          logWithTimestamp(`Почато вставку повідомлення в ${chatType}`);

          const selectors = CHAT_SELECTORS[chatType];

          // Знаходимо поле вводу - перевіряємо всі можливі селектори
          const inputSelectors = [
            selectors.inputField, 
            selectors.alternativeInputField, 
            selectors.altInputField
          ].filter(Boolean);

          let inputField = null;

          for (const selector of inputSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const el of elements) {
              if (isElementVisible(el)) {
                inputField = el;
                logWithTimestamp('Знайдено видиме поле вводу:', selector);
                break;
              }
            }
            if (inputField) break;
          }

          if (!inputField) {
            logWithTimestamp('Не знайдено поле вводу для', chatType);

            // Додаткова спроба знайти будь-яке можливе поле вводу
            const possibleInputs = document.querySelectorAll('textarea, [contenteditable="true"], div[role="textbox"], input[type="text"]');
            for (const el of possibleInputs) {
              if (isElementVisible(el)) {
                inputField = el;
                logWithTimestamp('Знайдено можливе поле вводу:', el);
                break;
              }
            }

            if (!inputField) {
              return { success: false, error: 'Не знайдено поле вводу' };
            }
          }

          // Знаходимо кнопку відправки
          const submitSelectors = [
            selectors.submitButton, 
            selectors.alternativeSubmitButton, 
            selectors.altSubmitButton
          ].filter(Boolean);

          let submitButton = null;

          for (const selector of submitSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const el of elements) {
              if (isElementVisible(el)) {
                submitButton = el;
                logWithTimestamp('Знайдено видиму кнопку відправки:', selector);
                break;
              }
            }
            if (submitButton) break;
          }

          if (!submitButton) {
            logWithTimestamp('Не знайдено кнопку відправки для', chatType, '- спробуємо використати Enter');

            // Спробуємо знайти будь-яку кнопку відправки
            const possibleButtons = document.querySelectorAll('button[type="submit"], button[aria-label*="Send"], button[aria-label*="send"], button:has(svg)');
            for (const el of possibleButtons) {
              if (isElementVisible(el)) {
                submitButton = el;
                logWithTimestamp('Знайдено можливу кнопку відправки:', el);
                break;
              }
            }
          }

          try {
            // Очищаємо поле вводу
            clearInputField(inputField);

            // Вставляємо текст з додатковою затримкою
            return new Promise((resolve) => {
              setTimeout(async () => {
                try {
                  // Фокусуємося на полі вводу
                  inputField.focus();

                  // Вставляємо текст в залежності від типу чату
                  switch(chatType) {
                    case 'claude.ai':
                      await handleClaudeMessage(inputField, messageText);
                      break;
                    case 'gemini.google.com':
                      await handleGeminiMessage(inputField, messageText);
                      break;
                    case 'grok.com':
                      await handleGrokMessage(inputField, messageText);
                      break;
                    case 'chat.openai.com':
                    case 'chatgpt.com':
                      await handleChatGptMessage(inputField, messageText);
                      break;
                    case 'chat.deepseek.com':
                      await handleDeepSeekMessage(inputField, messageText);
                      break;
                    default:
                      await handleGenericMessage(inputField, messageText);
                  }

                  // Додаємо затримку перед натисканням на кнопку
                  setTimeout(() => {
                    try {
                      if (submitButton && !submitButton.disabled && isElementVisible(submitButton)) {
                        logWithTimestamp('Натискаємо на кнопку відправки');
                        submitButton.click();

                        // Додатково викликаємо MouseEvent для більшої надійності
                        submitButton.dispatchEvent(new MouseEvent('click', {
                          bubbles: true,
                          cancelable: true,
                          view: window
                        }));

                        // Резервне відправлення через Enter
                        setTimeout(() => {
                          sendEnterKey(inputField);
                          resolve({ success: true });
                        }, 300);
                      } else {
                        logWithTimestamp('Кнопка відправки недоступна, відправляємо через Enter');
                        sendEnterKey(inputField);
                        resolve({ success: true });
                      }
                    } catch (error) {
                      logWithTimestamp('Помилка при натисканні кнопки:', error);
                      // Спробуємо відправити через Enter в будь-якому випадку
                      sendEnterKey(inputField);
                      resolve({ success: true });
                    }
                  }, 800);
                } catch (error) {
                  logWithTimestamp('Помилка при вставці повідомлення:', error);
                  resolve({ success: false, error: error.message });
                }
              }, 500);
            });
          } catch (error) {
            logWithTimestamp('Загальна помилка при вставці повідомлення:', error);
            return { success: false, error: error.message };
          }
        }

        // Функція для очищення поля вводу
        function clearInputField(inputField) {
          try {
            // Спочатку фокусуємося на полі вводу
            inputField.focus();

            // Перевіряємо тип елемента
            if (inputField.tagName.toLowerCase() === 'textarea' || inputField.tagName.toLowerCase() === 'input') {
              // Для текстових полів просто очищуємо значення
              inputField.value = '';
            } else if (inputField.getAttribute('contenteditable') === 'true') {
              // Для contenteditable елементів очищуємо вміст
              inputField.textContent = '';
              inputField.innerHTML = '';
            } else {
              // Універсальна очистка
              if (inputField.value !== undefined) inputField.value = '';
              if (inputField.textContent !== undefined) inputField.textContent = '';
              if (inputField.innerHTML !== undefined) inputField.innerHTML = '';
            }

            // Відправляємо подію input для повідомлення про зміни
            inputField.dispatchEvent(new Event('input', { bubbles: true }));

            logWithTimestamp('Поле вводу очищено');
          } catch (error) {
            logWithTimestamp('Помилка при очищенні поля вводу:', error);
          }
        }

        // Функція для відправки Enter натискання
        function sendEnterKey(element) {
          try {
            logWithTimestamp('Відправка Enter натискання');

            // Спочатку фокус на елементі
            element.focus();

            // Натискання з синтетичною подією - для більшості чатів цього достатньо
            element.dispatchEvent(new KeyboardEvent('keydown', { 
              key: 'Enter',
              code: 'Enter',
              keyCode: 13,
              which: 13,
              bubbles: true,
              cancelable: true,
              composed: true
            }));

            // Викликаємо нативний KeyboardEvent через виконання скрипта - для важких випадків
            const script = document.createElement('script');
            script.textContent = `
              (function() {
                const element = document.querySelector('${getCssSelector(element)}');
                if (element) {
                  element.focus();
                  const event = new KeyboardEvent('keydown', { 
                    key: 'Enter',
                    code: 'Enter',
                    keyCode: 13,
                    which: 13,
                    bubbles: true,
                    cancelable: true
                  });
                  element.dispatchEvent(event);
                }
              })();
            `;
            document.head.appendChild(script);
            document.head.removeChild(script);

            logWithTimestamp('Enter натискання відправлено успішно');
          } catch (error) {
            logWithTimestamp('Помилка при відправці Enter:', error);
          }
        }

        // Функція для отримання CSS селектора елемента
        function getCssSelector(element) {
          if (!element) return '';

          // Спрощений варіант - беремо найбільш важливі атрибути
          if (element.id) {
            return `#${element.id}`;
          }

          // Для текстових полів
          if (element.tagName.toLowerCase() === 'textarea') {
            return 'textarea';
          }

          // Для контентедітебл елементів
          if (element.getAttribute('contenteditable') === 'true') {
            return '[contenteditable="true"]';
          }

          // Загальний випадок - повертаємо просто тег
          return element.tagName.toLowerCase();
        }

        // Обробник для Claude
        async function handleClaudeMessage(inputField, messageText) {
          logWithTimestamp('Вставка повідомлення в Claude');

          // Спроба використати execCommand - найбільш надійний метод для contenteditable
          try {
            inputField.focus();
            document.execCommand('insertText', false, messageText);
            logWithTimestamp('Claude: Використано execCommand');
            return true;
          } catch (error) {
            logWithTimestamp('Claude: Помилка при використанні execCommand:', error);
          }

          // Якщо execCommand не працює, спробуємо інші методи
          try {
            // Спроба через clipboard event
            const clipboardData = new DataTransfer();
            clipboardData.setData('text/plain', messageText);

            const pasteEvent = new ClipboardEvent('paste', {
              bubbles: true,
              cancelable: true,
              clipboardData: clipboardData
            });

            inputField.dispatchEvent(pasteEvent);
            logWithTimestamp('Claude: Використано paste event');
            return true;
          } catch (error) {
            logWithTimestamp('Claude: Помилка при використанні paste event:', error);
          }

          // Остання спроба - прямий запис
          try {
            if (inputField.getAttribute('contenteditable') === 'true') {
              inputField.textContent = messageText;
            } else {
              inputField.value = messageText;
            }
            inputField.dispatchEvent(new Event('input', { bubbles: true }));
            logWithTimestamp('Claude: Використано пряму вставку');
            return true;
          } catch (error) {
            logWithTimestamp('Claude: Всі методи для Claude зазнали невдачі:', error);
            return false;
          }
        }

        // Обробник для Gemini - повністю переписаний
        async function handleGeminiMessage(inputField, messageText) {
          logWithTimestamp('Вставка повідомлення в Gemini');

          // Перевіряємо, чи це textarea, і використовуємо прямий метод
          if (inputField.tagName.toLowerCase() === 'textarea') {
            try {
              // Фокусуємося на елементі
              inputField.focus();

              // Встановлюємо значення
              inputField.value = messageText;

              // Викликаємо подію input кілька разів для надійності
              for (let i = 0; i < 3; i++) {
                await new Promise(resolve => setTimeout(() => {
                  inputField.dispatchEvent(new Event('input', { bubbles: true }));
                  resolve();
                }, 100));
              }

              // Додатково викликаємо change подію
              inputField.dispatchEvent(new Event('change', { bubbles: true }));

              logWithTimestamp('Gemini: Використано пряму вставку в textarea');
              return true;
            } catch (error) {
              logWithTimestamp('Gemini: Помилка при вставці в textarea:', error);
            }
          }

          // Альтернативний метод - створення скрипта, що виконується в контексті сторінки
          try {
            const script = document.createElement('script');

            script.textContent = `
              (function() {
                // Знаходимо всі можливі поля вводу
                const inputs = document.querySelectorAll('textarea, [contenteditable="true"]');
                let success = false;

                inputs.forEach(input => {
                  if (!success && (getComputedStyle(input).display !== 'none')) {
                    try {
                      input.focus();

                      if (input.tagName.toLowerCase() === 'textarea') {
                        input.value = ${JSON.stringify(messageText)};
                      } else {
                        input.textContent = ${JSON.stringify(messageText)};
                      }

                      // Створюємо та диспетчеризуємо подію input
                      input.dispatchEvent(new Event('input', { bubbles: true }));
                      input.dispatchEvent(new Event('change', { bubbles: true }));

                      console.log('Gemini: Текст встановлено успішно через скрипт');
                      success = true;
                    } catch (e) {
                      console.error('Gemini: Помилка при встановленні тексту:', e);
                    }
                  }
                });
              })();
            `;

            document.head.appendChild(script);
            document.head.removeChild(script);

            logWithTimestamp('Gemini: Виконано вставку через script injection');
            return true;
          } catch (error) {
            logWithTimestamp('Gemini: Помилка при вставці через script injection:', error);
          }

          // Останній резервний метод
          try {
            if (inputField.value !== undefined) {
              inputField.value = messageText;
            } else if (inputField.textContent !== undefined) {
              inputField.textContent = messageText;
            }

            inputField.dispatchEvent(new Event('input', { bubbles: true }));

            logWithTimestamp('Gemini: Використано базовий резервний метод');
            return true;
          } catch (error) {
            logWithTimestamp('Gemini: Всі методи для Gemini зазнали невдачі:', error);
            return false;
          }
        }

        // Обробник для Grok - повністю переписаний
        async function handleGrokMessage(inputField, messageText) {
          logWithTimestamp('Вставка повідомлення в Grok');

          // Пробуємо використати нативний script injection - найнадійніший метод
          try {
            const script = document.createElement('script');

            script.textContent = `
              (function() {
                // Знаходимо textarea елемент - Grok використовує різні класи
                const textareas = document.querySelectorAll('textarea');
                let foundTextarea = null;

                // Знаходимо видиму textarea
                for (const textarea of textareas) {
                  if (getComputedStyle(textarea).display !== 'none') {
                    foundTextarea = textarea;
                    break;
                  }
                }

                if (foundTextarea) {
                  // Очищаємо вміст
                  foundTextarea.value = '';

                  // Встановлюємо новий текст
                  foundTextarea.value = ${JSON.stringify(messageText)};

                  // Викликаємо події
                  foundTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                  foundTextarea.dispatchEvent(new Event('change', { bubbles: true }));

                  console.log('Grok: Текст встановлено успішно через скрипт');
                } else {
                  console.error('Grok: Не знайдено textarea елемент');
                }
              })();
            `;

            document.head.appendChild(script);
            document.head.removeChild(script);

            logWithTimestamp('Grok: Виконано вставку через script injection');

            // Додаткова перевірка - пробуємо також прямий метод для підстраховки
            setTimeout(() => {
              try {
                inputField.value = messageText;
                inputField.dispatchEvent(new Event('input', { bubbles: true }));
                logWithTimestamp('Grok: Додатково виконано прямий метод');
              } catch (e) {
                logWithTimestamp('Grok: Помилка при додатковому методі:', e);
              }
            }, 100);

            return true;
          } catch (error) {
            logWithTimestamp('Grok: Помилка при вставці через script injection:', error);
          }

          // Резервний метод - пряма вставка
          try {
            // Фокусуємо на елементі
            inputField.focus();

            // Встановлюємо значення
            if (inputField.tagName.toLowerCase() === 'textarea') {
              inputField.value = messageText;
            } else {
              inputField.textContent = messageText;
            }

            // Диспетчеризуємо події
            ['input', 'change'].forEach(eventType => {
              inputField.dispatchEvent(new Event(eventType, { bubbles: true }));
            });

            logWithTimestamp('Grok: Використано пряму вставку');
            return true;
          } catch (error) {
            logWithTimestamp('Grok: Всі методи для Grok зазнали невдачі:', error);
            return false;
          }
        }

        // Обробник для ChatGPT
        async function handleChatGptMessage(inputField, messageText) {
          logWithTimestamp('Вставка повідомлення в ChatGPT');

          // Встановлюємо значення двома методами
          try {
            if (inputField.value !== undefined) {
              inputField.value = messageText;
            }
            if (inputField.innerHTML !== undefined) {
              inputField.innerHTML = messageText;
            }

            // Додаткова перевірка для contenteditable елементів
            if (inputField.getAttribute('contenteditable') === 'true') {
              inputField.textContent = messageText;
            }

            // Симулюємо події
            const events = ['focus', 'input', 'change'];
            for (const eventType of events) {
              await new Promise(resolve => {
                setTimeout(() => {
                  try {
                    if (eventType === 'input') {
                      try {
                        inputField.dispatchEvent(new InputEvent('input', { 
                          bubbles: true,
                          data: messageText,
                          inputType: 'insertText'
                        }));
                      } catch (e) {
                        inputField.dispatchEvent(new Event('input', { bubbles: true }));
                      }
                    } else {
                      inputField.dispatchEvent(new Event(eventType, { bubbles: true }));
                    }
                  } catch (error) {
                    logWithTimestamp(`ChatGPT: Помилка при відправці події ${eventType}:`, error);
                  }
                  resolve();
                }, 50);
              });
            }

            logWithTimestamp('ChatGPT: Успішно встановлено текст');
            return true;
          } catch (error) {
            logWithTimestamp('Помилка при обробці ChatGPT:', error);
            return false;
          }
        }

        // Обробник для DeepSeek
        async function handleDeepSeekMessage(inputField, messageText) {
          logWithTimestamp('Вставка повідомлення в DeepSeek');

          try {
            // Фокусуємо на полі вводу
            inputField.focus();

            // Встановлюємо значення в залежності від типу елемента
            if (inputField.value !== undefined) {
              inputField.value = messageText;
            } else if (inputField.tagName.toLowerCase() === 'div' && inputField.getAttribute('contenteditable') === 'true') {
              inputField.textContent = messageText;
            }

            // Відправляємо події
            ['input', 'change'].forEach(eventType => {
              inputField.dispatchEvent(new Event(eventType, { bubbles: true }));
            });

            logWithTimestamp('DeepSeek: Успішно встановлено текст');
            return true;
          } catch (error) {
            logWithTimestamp('Помилка при обробці DeepSeek:', error);
            return false;
          }
        }

        // Універсальний обробник для інших чатів
        async function handleGenericMessage(inputField, messageText) {
          logWithTimestamp('Вставка повідомлення через універсальний обробник');

          try {
            // Фокусуємо на елементі
            inputField.focus();

            // Встановлюємо значення в залежності від типу елемента
            if (inputField.tagName.toLowerCase() === 'textarea' || inputField.tagName.toLowerCase() === 'input') {
              inputField.value = messageText;
            } else if (inputField.getAttribute('contenteditable') === 'true') {
              inputField.textContent = messageText;
            } else {
              // Якщо нічого не підходить, спробуємо обидва методи
              if (inputField.value !== undefined) inputField.value = messageText;
              if (inputField.textContent !== undefined) inputField.textContent = messageText;
              if (inputField.innerHTML !== undefined) inputField.innerHTML = messageText;
            }

            // Відправляємо події
            const events = ['input', 'change'];
            for (const eventType of events) {
              await new Promise(resolve => {
                setTimeout(() => {
                  try {
                    inputField.dispatchEvent(new Event(eventType, { bubbles: true }));
                  } catch (error) {
                    logWithTimestamp(`Generic: Помилка при відправці події ${eventType}:`, error);
                  }
                  resolve();
                }, 50);
              });
            }

            logWithTimestamp('Generic: Успішно встановлено текст');
            return true;
          } catch (error) {
            logWithTimestamp('Помилка при обробці універсального повідомлення:', error);
            return false;



            logWithTimestamp('Generic: Успішно встановлено текст');
                return true;
              } catch (error) {
                logWithTimestamp('Помилка при обробці універсального повідомлення:', error);
                return false;
              }
            }

            // Функція для перевірки, чи елемент видимий на сторінці
            function isElementVisible(element) {
              if (!element) return false;

              try {
                const style = window.getComputedStyle(element);
                const rect = element.getBoundingClientRect();

                return style.display !== 'none' && 
                      style.visibility !== 'hidden' && 
                      style.opacity !== '0' &&
                      parseFloat(style.opacity) > 0 &&
                      rect.width > 0 && 
                      rect.height > 0;
              } catch (error) {
                logWithTimestamp('Помилка при перевірці видимості елемента:', error);
                // Спрощена перевірка для випадку помилки
                return element.offsetWidth > 0 && element.offsetHeight > 0;
              }
            }

            // Функція для спостереження за змінами в DOM
            // Це дозволить адаптуватися до змін інтерфейсу чатів
            function observeDOMChanges() {
              try {
                // Створення MutationObserver для відстеження змін DOM
                const observer = new MutationObserver((mutations) => {
                  // Будемо реагувати тільки на значні зміни в DOM
                  const significantChanges = mutations.some(mutation => 
                    mutation.addedNodes.length > 0 || 
                    mutation.removedNodes.length > 0 ||
                    (mutation.type === 'attributes' && 
                     (mutation.attributeName === 'class' || mutation.attributeName === 'style'))
                  );

                  if (significantChanges) {
                    logWithTimestamp('Виявлено значні зміни в DOM');
                    // Можна додати додаткову логіку перевірки елементів
                  }
                });

                // Налаштування параметрів спостереження
                const observerConfig = {
                  childList: true,
                  subtree: true,
                  attributes: true,
                  attributeFilter: ['class', 'style']
                };

                // Початок спостереження за body
                observer.observe(document.body, observerConfig);

                logWithTimestamp('DOM спостереження активовано');
                return observer;
              } catch (error) {
                logWithTimestamp('Помилка при налаштуванні DOM спостереження:', error);
                return null;
              }
            }

            // Додаткова функція для обробки відправки повідомлення через натискання Shift+Enter
            function setupShiftEnterHandler() {
              try {
                document.addEventListener('keydown', (event) => {
                  // Перевіряємо, чи натиснуто Shift+Enter
                  if (event.key === 'Enter' && event.shiftKey) {
                    logWithTimestamp('Виявлено натискання Shift+Enter');

                    // Отримуємо поточний тип чату
                    const chatType = getCurrentChatType();
                    if (!chatType) return;

                    // Отримуємо селектори для поточного чату
                    const selectors = CHAT_SELECTORS[chatType];
                    if (!selectors) return;

                    // Знаходимо поле вводу
                    const inputSelectors = [
                      selectors.inputField, 
                      selectors.alternativeInputField, 
                      selectors.altInputField
                    ].filter(Boolean);

                    // Перевіряємо, чи є активний елемент одним з полів вводу
                    const activeElement = document.activeElement;
                    const isInputField = inputSelectors.some(selector => {
                      const elements = document.querySelectorAll(selector);
                      return Array.from(elements).includes(activeElement);
                    });

                    // Якщо активний елемент є полем вводу, обробляємо натискання
                    if (isInputField) {
                      logWithTimestamp('Виявлено натискання Shift+Enter в полі вводу');

                      // Можна додати додаткову логіку для обробки натискання Shift+Enter
                      // Наприклад, додавання нового рядка замість відправки
                    }
                  }
                });

                logWithTimestamp('Обробник Shift+Enter встановлено');
              } catch (error) {
                logWithTimestamp('Помилка при встановленні обробника Shift+Enter:', error);
              }
            }

            // Функція для розбиття великих повідомлень на менші частини
            function splitLargeMessage(message, maxLength = 12000) {
              if (!message || message.length <= maxLength) {
                return [message];
              }

              logWithTimestamp(`Розбиття великого повідомлення (${message.length} символів) на частини`);

              // Розбиваємо повідомлення на частини
              const parts = [];
              let currentPosition = 0;

              while (currentPosition < message.length) {
                // Знаходимо точку розділення - краще на кінці речення або абзацу
                let splitPosition = currentPosition + maxLength;

                if (splitPosition >= message.length) {
                  splitPosition = message.length;
                } else {
                  // Шукаємо найближчий кінець абзацу
                  const paragraphEnd = message.lastIndexOf('\n\n', splitPosition);
                  if (paragraphEnd > currentPosition && paragraphEnd > splitPosition - 500) {
                    splitPosition = paragraphEnd + 2;
                  } else {
                    // Шукаємо найближчий кінець речення
                    const sentenceEnd = Math.max(
                      message.lastIndexOf('. ', splitPosition),
                      message.lastIndexOf('! ', splitPosition),
                      message.lastIndexOf('? ', splitPosition),
                      message.lastIndexOf('.\n', splitPosition),
                      message.lastIndexOf('!\n', splitPosition),
                      message.lastIndexOf('?\n', splitPosition)
                    );

                    if (sentenceEnd > currentPosition && sentenceEnd > splitPosition - 500) {
                      splitPosition = sentenceEnd + 2;
                    } else {
                      // Шукаємо найближчий кінець рядка
                      const lineEnd = message.lastIndexOf('\n', splitPosition);
                      if (lineEnd > currentPosition && lineEnd > splitPosition - 500) {
                        splitPosition = lineEnd + 1;
                      }
                    }
                  }
                }

                // Додаємо частину до масиву
                parts.push(message.slice(currentPosition, splitPosition));
                currentPosition = splitPosition;
              }

              logWithTimestamp(`Повідомлення розбито на ${parts.length} частин`);
              return parts;
            }

            // Функція для перевірки теми сторінки (світла/темна)
            function detectPageTheme() {
              try {
                // Перевіряємо наявність data-атрибутів теми
                const html = document.documentElement;
                const themeAttribute = html.getAttribute('data-theme') || 
                                      html.getAttribute('theme') || 
                                      document.body.getAttribute('data-theme');

                if (themeAttribute) {
                  if (themeAttribute.includes('dark')) {
                    return 'dark';
                  }
                  if (themeAttribute.includes('light')) {
                    return 'light';
                  }
                }

                // Перевіряємо CSS змінні
                const computedStyle = getComputedStyle(document.body);
                const backgroundColor = computedStyle.backgroundColor;

                // Спрощена перевірка яскравості
                if (backgroundColor) {
                  // Видобуваємо RGB компоненти
                  const rgb = backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
                  if (rgb) {
                    const [_, r, g, b] = rgb.map(Number);
                    // Формула для визначення яскравості
                    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
                    return brightness < 128 ? 'dark' : 'light';
                  }
                }

                // За замовчуванням, припускаємо світлу тему
                return 'light';
              } catch (error) {
                logWithTimestamp('Помилка при визначенні теми сторінки:', error);
                return 'light'; // За замовчуванням
              }
            }

            // Ініціалізуємо додаткові компоненти
            try {
              // Активуємо спостереження за DOM
              const domObserver = observeDOMChanges();

              // Встановлюємо обробник Shift+Enter
              setupShiftEnterHandler();

              // Визначаємо тему сторінки
              const pageTheme = detectPageTheme();
              logWithTimestamp(`Виявлена тема сторінки: ${pageTheme}`);

              // Інші ініціалізації
              logWithTimestamp('Розширення ініціалізовано успішно');
            } catch (error) {
              logWithTimestamp('Помилка при ініціалізації розширення:', error);
            }logWithTimestamp('Generic: Успішно встановлено текст');
    return true;
  } catch (error) {
    logWithTimestamp('Помилка при обробці універсального повідомлення:', error);
    return false;
  }
}

// Функція для перевірки, чи елемент видимий на сторінці
function isElementVisible(element) {
  if (!element) return false;

  try {
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();

    return style.display !== 'none' && 
          style.visibility !== 'hidden' && 
          style.opacity !== '0' &&
          parseFloat(style.opacity) > 0 &&
          rect.width > 0 && 
          rect.height > 0;
  } catch (error) {
    logWithTimestamp('Помилка при перевірці видимості елемента:', error);
    // Спрощена перевірка для випадку помилки
    return element.offsetWidth > 0 && element.offsetHeight > 0;
  }
}

// Функція для спостереження за змінами в DOM
// Це дозволить адаптуватися до змін інтерфейсу чатів
function observeDOMChanges() {
  try {
    // Створення MutationObserver для відстеження змін DOM
    const observer = new MutationObserver((mutations) => {
      // Будемо реагувати тільки на значні зміни в DOM
      const significantChanges = mutations.some(mutation => 
        mutation.addedNodes.length > 0 || 
        mutation.removedNodes.length > 0 ||
        (mutation.type === 'attributes' && 
         (mutation.attributeName === 'class' || mutation.attributeName === 'style'))
      );

      if (significantChanges) {
        logWithTimestamp('Виявлено значні зміни в DOM');
        // Можна додати додаткову логіку перевірки елементів
      }
    });

    // Налаштування параметрів спостереження
    const observerConfig = {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'style']
    };

    // Початок спостереження за body
    observer.observe(document.body, observerConfig);

    logWithTimestamp('DOM спостереження активовано');
    return observer;
  } catch (error) {
    logWithTimestamp('Помилка при налаштуванні DOM спостереження:', error);
    return null;
  }
}

// Додаткова функція для обробки відправки повідомлення через натискання Shift+Enter
function setupShiftEnterHandler() {
  try {
    document.addEventListener('keydown', (event) => {
      // Перевіряємо, чи натиснуто Shift+Enter
      if (event.key === 'Enter' && event.shiftKey) {
        logWithTimestamp('Виявлено натискання Shift+Enter');

        // Отримуємо поточний тип чату
        const chatType = getCurrentChatType();
        if (!chatType) return;

        // Отримуємо селектори для поточного чату
        const selectors = CHAT_SELECTORS[chatType];
        if (!selectors) return;

        // Знаходимо поле вводу
        const inputSelectors = [
          selectors.inputField, 
          selectors.alternativeInputField, 
          selectors.altInputField
        ].filter(Boolean);

        // Перевіряємо, чи є активний елемент одним з полів вводу
        const activeElement = document.activeElement;
        const isInputField = inputSelectors.some(selector => {
          const elements = document.querySelectorAll(selector);
          return Array.from(elements).includes(activeElement);
        });

        // Якщо активний елемент є полем вводу, обробляємо натискання
        if (isInputField) {
          logWithTimestamp('Виявлено натискання Shift+Enter в полі вводу');

          // Можна додати додаткову логіку для обробки натискання Shift+Enter
          // Наприклад, додавання нового рядка замість відправки
        }
      }
    });

    logWithTimestamp('Обробник Shift+Enter встановлено');
  } catch (error) {
    logWithTimestamp('Помилка при встановленні обробника Shift+Enter:', error);
  }
}

// Функція для розбиття великих повідомлень на менші частини
function splitLargeMessage(message, maxLength = 12000) {
  if (!message || message.length <= maxLength) {
    return [message];
  }

  logWithTimestamp(`Розбиття великого повідомлення (${message.length} символів) на частини`);

  // Розбиваємо повідомлення на частини
  const parts = [];
  let currentPosition = 0;

  while (currentPosition < message.length) {
    // Знаходимо точку розділення - краще на кінці речення або абзацу
    let splitPosition = currentPosition + maxLength;

    if (splitPosition >= message.length) {
      splitPosition = message.length;
    } else {
      // Шукаємо найближчий кінець абзацу
      const paragraphEnd = message.lastIndexOf('\n\n', splitPosition);
      if (paragraphEnd > currentPosition && paragraphEnd > splitPosition - 500) {
        splitPosition = paragraphEnd + 2;
      } else {
        // Шукаємо найближчий кінець речення
        const sentenceEnd = Math.max(
          message.lastIndexOf('. ', splitPosition),
          message.lastIndexOf('! ', splitPosition),
          message.lastIndexOf('? ', splitPosition),
          message.lastIndexOf('.\n', splitPosition),
          message.lastIndexOf('!\n', splitPosition),
          message.lastIndexOf('?\n', splitPosition)
        );

        if (sentenceEnd > currentPosition && sentenceEnd > splitPosition - 500) {
          splitPosition = sentenceEnd + 2;
        } else {
          // Шукаємо найближчий кінець рядка
          const lineEnd = message.lastIndexOf('\n', splitPosition);
          if (lineEnd > currentPosition && lineEnd > splitPosition - 500) {
            splitPosition = lineEnd + 1;
          }
        }
      }
    }

    // Додаємо частину до масиву
    parts.push(message.slice(currentPosition, splitPosition));
    currentPosition = splitPosition;
  }

  logWithTimestamp(`Повідомлення розбито на ${parts.length} частин`);
  return parts;
}

// Функція для перевірки теми сторінки (світла/темна)
function detectPageTheme() {
  try {
    // Перевіряємо наявність data-атрибутів теми
    const html = document.documentElement;
    const themeAttribute = html.getAttribute('data-theme') || 
                          html.getAttribute('theme') || 
                          document.body.getAttribute('data-theme');

    if (themeAttribute) {
      if (themeAttribute.includes('dark')) {
        return 'dark';
      }
      if (themeAttribute.includes('light')) {
        return 'light';
      }
    }

    // Перевіряємо CSS змінні
    const computedStyle = getComputedStyle(document.body);
    const backgroundColor = computedStyle.backgroundColor;

    // Спрощена перевірка яскравості
    if (backgroundColor) {
      // Видобуваємо RGB компоненти
      const rgb = backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (rgb) {
        const [_, r, g, b] = rgb.map(Number);
        // Формула для визначення яскравості
        const brightness = (r * 299 + g * 587 + b * 114) / 1000;
        return brightness < 128 ? 'dark' : 'light';
      }
    }

    // За замовчуванням, припускаємо світлу тему
    return 'light';
  } catch (error) {
    logWithTimestamp('Помилка при визначенні теми сторінки:', error);
    return 'light'; // За замовчуванням
  }
}

// Ініціалізуємо додаткові компоненти
try {
  // Активуємо спостереження за DOM
  const domObserver = observeDOMChanges();

  // Встановлюємо обробник Shift+Enter
  setupShiftEnterHandler();

  // Визначаємо тему сторінки
  const pageTheme = detectPageTheme();
  logWithTimestamp(`Виявлена тема сторінки: ${pageTheme}`);

  // Інші ініціалізації
  logWithTimestamp('Розширення ініціалізовано успішно');
} catch (error) {
  logWithTimestamp('Помилка при ініціалізації розширення:', error);
}

            